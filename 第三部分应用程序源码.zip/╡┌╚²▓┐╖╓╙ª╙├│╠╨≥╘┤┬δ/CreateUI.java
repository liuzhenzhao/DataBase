/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author liuzhenzhao
 */
public class CreateUI 
{

    public static Stage stage;
    String fxmlpath;
    public CreateUI(String fxmlpath)
    {
        this.fxmlpath=fxmlpath;
        stage=new Stage();
    }
    //@Override
     public void start(Stage primaryStage) throws Exception
     {  
        Parent root = FXMLLoader.load(getClass().getResource(this.fxmlpath));
        primaryStage.setScene(new Scene(root));  
        //primaryStage.setMaximized(true);
        primaryStage.show();   
    }  
  
    public static void main(String[] args) {  
        launch(args);  
    }  
      
    public void  showWindow() throws Exception {  
        start(stage);  
    }  
    
}
