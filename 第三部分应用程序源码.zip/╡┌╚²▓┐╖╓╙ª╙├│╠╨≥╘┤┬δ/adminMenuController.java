/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author liuzhenzhao
 */
public class adminMenuController implements Initializable {

    private ArrayList<ReaderInfo> data=new ArrayList<ReaderInfo>();
    private ObservableList<ReaderInfo> list=FXCollections.observableArrayList();
    @FXML
    private Tab manageBookInfo;
    @FXML
    private Button addNewBook;
    @FXML
    private Button queryBookInfo;
    @FXML
    private Tab manageReaderInfo;
    @FXML
    private Button query;
    @FXML
    private TableColumn<ReaderInfo,String> Account;
    @FXML
    private TableColumn<ReaderInfo,String> Name;
    @FXML
    private TableColumn<ReaderInfo,String> deptName;
    @FXML
    private TableColumn<ReaderInfo,String> deptNo;
    @FXML
    private TableColumn<ReaderInfo,String> Tel;
    @FXML
    private TableColumn<ReaderInfo,String> passWord;
    @FXML
    private TableColumn<ReaderInfo,Integer> constraint;
    @FXML
    private Tab returnBook;
    @FXML
    private ChoiceBox<String> bookstate;
    @FXML
    private TextField shouldPay;
    @FXML
    private TextField bookNo;
    @FXML
    private Button OK;
    @FXML
    private TextField havePay;
    @FXML
    private ChoiceBox<String> queryMode;
    @FXML
    private TextField queryObject;
    @FXML
    private TableView<ReaderInfo> readerTable;
    @FXML
    private Button submit;
    @FXML
    private Button addReader;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
        queryMode.getItems().addAll("按姓名查询","按账号查询","按联系方式查询","查询全部");
        queryMode.setValue("查询全部");
        bookstate.getItems().addAll("正常","损坏或丢失");
        bookstate.setValue("正常");
        Account.setCellValueFactory(new PropertyValueFactory<ReaderInfo,String>("account"));
        Name.setCellValueFactory(new PropertyValueFactory<ReaderInfo,String>("name"));
        Name.setCellFactory(TextFieldTableCell.<ReaderInfo>forTableColumn());
        Name.setOnEditCommit((TableColumn.CellEditEvent<ReaderInfo, String> t) -> {
            ((ReaderInfo) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())
                    ).setName(t.getNewValue());
        });
        deptName.setCellValueFactory(new PropertyValueFactory<ReaderInfo,String>("deptName"));
        deptNo.setCellValueFactory(new PropertyValueFactory<ReaderInfo,String>("deptNo"));
        deptNo.setCellFactory(TextFieldTableCell.<ReaderInfo>forTableColumn());
        deptNo.setOnEditCommit((TableColumn.CellEditEvent<ReaderInfo, String> t) -> {
            ((ReaderInfo) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())
                    ).setDeptNo(t.getNewValue());
        });
        Tel.setCellValueFactory(new PropertyValueFactory<ReaderInfo,String>("tel"));
        Tel.setCellFactory(TextFieldTableCell.<ReaderInfo>forTableColumn());
        Tel.setOnEditCommit((TableColumn.CellEditEvent<ReaderInfo, String> t) -> {
            ((ReaderInfo) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())
                    ).setTel(t.getNewValue());
        });
        passWord.setCellValueFactory(new PropertyValueFactory<ReaderInfo,String>("password"));
        passWord.setCellFactory(TextFieldTableCell.<ReaderInfo>forTableColumn());
        passWord.setOnEditCommit((TableColumn.CellEditEvent<ReaderInfo, String> t) -> {
            ((ReaderInfo) t.getTableView().getItems().get(
                    t.getTablePosition().getRow())
                    ).setPassword(t.getNewValue());
        });
        constraint.setCellValueFactory(new PropertyValueFactory<ReaderInfo,Integer>("authority"));
        readerTable.setItems(list);
        
    }    

    @FXML
    private void computeShouldPay(MouseEvent event) 
    {
        System.out.println("start to compute how much you should pay");
    }

    @FXML
    private void out(ActionEvent event) 
    {
        System.out.println("start to out");
    }

    @FXML
    private void addNewBook(ActionEvent event) throws Exception 
    {
        CreateUI ui=new CreateUI("AddNewBook.fxml");
        ui.showWindow();
    }

    private void delOldBook(ActionEvent event) throws Exception 
    {
        //CreateUI ui=new CreateUI("delOldBook.fxml");
        //ui.showWindow();
    }

    @FXML
    private void queryBookInfo(ActionEvent event) throws Exception 
    {
        CreateUI ui=new CreateUI("AdminQueryBook.fxml");
        ui.showWindow();
    }

    @FXML
    private void queryReader(ActionEvent event) throws ClassNotFoundException, SQLException 
    {
        readerTable.getItems().clear();
        String temp=queryMode.getValue();
        String o=queryObject.getText();
        String sql=null;
        if(temp.equals("按账号查询"))
        {
            sql="select t1.Account as Account,t1.Name as Name,t2.Name as Dept,t1.DeptNo as DeptNo,t1.Tel as Tel,"
                    + "t1.Password as Password,t1.Authority as Authority"
                    + " from Reader t1,Dept t2 where t1.DeptNo=t2.No and t1.Account='"+o+"'";
        }
        else if(temp.equals("按姓名查询"))
        {
            sql="select t1.Account as Account,t1.Name as Name,t2.Name as Dept,t1.DeptNo as DeptNo,t1.Tel as Tel,"
                    + "t1.Password as Password,t1.Authority as Authority"
                    + " from Reader t1,Dept t2 where t1.DeptNo=t2.No and t1.Name='"+o+"'";
        }
        else if(temp.equals("按联系方式查询"))
        {
            sql="select t1.Account as Account,t1.Name as Name,t2.Name as Dept,t1.DeptNo as DeptNo,t1.Tel as Tel,"
                    + "t1.Password as Password,t1.Authority as Authority"
                    + " from Reader t1,Dept t2 where t1.DeptNo=t2.No and t1.Tel='"+o+"'";
        }
        else if(temp.equals("查询全部"))
        {
            sql="select t1.Account as Account,t1.Name as Name,t2.Name as Dept,t1.DeptNo as DeptNo,t1.Tel as Tel,"
                    + "t1.Password as Password,t1.Authority as Authority"
                    + " from Reader t1,Dept t2 where t1.DeptNo=t2.No";
        }
        ResultSet rs=null;
        Statement stmt = null;
        Connection conn = null;
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        System.out.println(sql);
        rs=stmt.executeQuery(sql);
        while(rs.next())
        {
            list.add(new ReaderInfo(rs.getString("Account"),rs.getString("Password"),rs.getString("Name"),
            rs.getString("Dept"),String.valueOf(rs.getInt("DeptNo")),rs.getString("Tel"),rs.getInt("Authority")));
        }
        readerTable.setItems(list);
        if(stmt != null)
        {
            stmt.close();
            stmt = null;
        }
        if(conn != null)
        {
            conn.close();
            conn = null;
        }
        if(rs!=null)
       {
           rs.close();
           rs = null;
        }
    }

    @FXML
    private void startComputeTicket(ActionEvent event) throws ClassNotFoundException, SQLException 
    {
        double extra=0;
        double total=0;
        int dst=Integer.parseInt(bookNo.getText());//获得图书编号
        if(bookstate.getValue().equals("正常"))//罚款=extra(损坏赔偿)+Total(逾期罚金)
        {
            extra=0;
        }
        else if(bookstate.getValue().equals("损坏或丢失"))
        {
            extra=50;
        }
        ResultSet rs1=null;
        Statement stmt = null;
        Connection conn = null;
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        String sql1="select TOTAL from Ticket where BOOKNO="+dst;
        rs1=stmt.executeQuery(sql1);
        while(rs1.next())
        {//在Ticket表中查询该图书对应读者的罚金
            total=rs1.getDouble("TOTAL");
        }
        shouldPay.setText(String.valueOf(total+extra));
        if(stmt != null)
        {
            stmt.close();
            stmt = null;
        }
        if(conn != null)
        {
            conn.close();
            conn = null;
        }
        if(rs1!=null)
       {
           rs1.close();
           rs1 = null;
        }
    }

    @FXML
    private void okReturnBook(ActionEvent event) throws SQLException, ClassNotFoundException 
    {
        ResultSet rs=null;
        Statement stmt = null;
        Connection conn = null;
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        String sql=null;
        double a1=Double.valueOf(shouldPay.getText());
        double a2=Double.valueOf(havePay.getText());
        if(a1>a2)
        {
            Alert alert=new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnning");
            alert.setContentText("请先收取罚金");
            alert.showAndWait();
            return;
        }
        if(bookstate.getValue().equals("损坏或丢失"))
        {//从book表中删除这本图书
            sql="delete from BOOK where NO="+Integer.valueOf(bookNo.getText());
            stmt.executeUpdate(sql);
            System.out.println(sql);
            bookNo.clear();
            shouldPay.clear();
            havePay.setText("0");
            bookstate.setValue("正常");
        }
        else if(bookstate.getValue().equals("正常"))
        {
            sql="delete from TICKET where BOOKNO="+Integer.valueOf(bookNo.getText());
            stmt.executeUpdate(sql);
            System.out.println(sql);
            sql="delete from BORROW where BOOKNO="+Integer.valueOf(bookNo.getText());
            stmt.executeUpdate(sql);
            System.out.println(sql);
            sql="delete from CACHE where BOOKNO="+Integer.valueOf(bookNo.getText());
            stmt.executeUpdate(sql);
            System.out.println(sql);
            sql="update BOOK set STATE='在架上' "
                    + "where NO="+Integer.valueOf(bookNo.getText());
            System.out.println(sql);
            stmt.executeUpdate(sql);
            bookNo.clear();
            shouldPay.setText("0");
            havePay.setText("0");
            bookstate.setValue("正常");
        }
        if(stmt != null)
        {
            stmt.close();
            stmt = null;
        }
        if(conn != null)
        {
            conn.close();
            conn = null;
        }
        if(rs!=null)
       {
           rs.close();
           rs = null;
        }
    }

    @FXML
    private void manageReaderInfo(Event event) throws ClassNotFoundException, SQLException 
    {
        if(manageReaderInfo.isSelected())
        {
            String sql="select t1.Account as Account,t1.Name as Name,t2.Name as Dept,t1.DeptNo as DeptNo,t1.Tel as Tel,"
                    + "t1.Password as Password,t1.Authority as Authority"
                    + " from Reader t1,Dept t2 where t1.DeptNo=t2.No";
            ResultSet rs=null;
            Statement stmt = null;
            Connection conn = null;
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
            stmt = conn.createStatement();
            rs=stmt.executeQuery(sql);
            while(rs.next())
            {
                list.add(new ReaderInfo(rs.getString("Account"),rs.getString("Password"),rs.getString("Name"),
                        rs.getString("Dept"),String.valueOf(rs.getInt("DeptNo")),rs.getString("Tel"),rs.getInt("Authority")));
            }
            readerTable.setItems(list);
            if(stmt != null)
            {
                stmt.close();
                stmt = null;
            }
            if(conn != null)
            {
                conn.close();
                conn = null;
            }
            if(rs!=null)
            {
                rs.close();
                rs = null;
            }
        }
        else if(!manageReaderInfo.isSelected())
        {
            readerTable.getItems().clear();
        }
    }

    @FXML
    private void modifyReader(MouseEvent event) throws ClassNotFoundException, SQLException 
    {
        ResultSet rs=null;
        Statement stmt = null;
        Connection conn = null;
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        String sql=null;
        if(event.getButton()==MouseButton.SECONDARY&&!readerTable.getSelectionModel().isEmpty())
        {
           Alert alert=new Alert(Alert.AlertType.CONFIRMATION,null,new ButtonType("取消", ButtonBar.ButtonData.CANCEL_CLOSE),new ButtonType("删除此项", ButtonBar.ButtonData.OK_DONE),
            new ButtonType("提交修改", ButtonBar.ButtonData.FINISH));
           Optional<ButtonType> _buttonType = alert.showAndWait();
           if(_buttonType.get().getButtonData().equals(ButtonBar.ButtonData.OK_DONE))
           {
               sql="delete from READER where ACCOUNT='"+readerTable.getSelectionModel().getSelectedItem().getAccount()+"'";
               System.out.println(sql);
               stmt.executeUpdate(sql);
           }
           else if(_buttonType.get().getButtonData().equals(ButtonBar.ButtonData.FINISH))
           {
               String account=readerTable.getSelectionModel().getSelectedItem().getAccount();
               String password=readerTable.getSelectionModel().getSelectedItem().getPassword();
               String name=readerTable.getSelectionModel().getSelectedItem().getName();
               String deptno=readerTable.getSelectionModel().getSelectedItem().getDeptNo();
               String tel=readerTable.getSelectionModel().getSelectedItem().getTel();
               int authority=readerTable.getSelectionModel().getSelectedItem().getAuthority();
               sql="update READER set (PASSWORD,NAME,DEPTNO,TEL,AUTHORITY)=(select '"+password+"','"+name+"',"+Integer.parseInt(deptno)+",'"
                       +tel+"',"+authority+" from dual) where ACCOUNT='"+account+"'";
               System.out.println(sql);
               stmt.executeUpdate(sql);
           }
           if(stmt != null) 
           {  
                stmt.close();  
                stmt = null;  
            }  
            if(conn != null) 
            {  
                conn.close();  
                conn = null;  
            }
            if(rs!=null)
            {
                rs.close();
                rs = null;
            }
        }
    }

    @FXML
    private void addNewReader(ActionEvent event) throws Exception 
    {
        CreateUI ui=new CreateUI("AdminAddReader.fxml");
        ui.showWindow();
    }
    public static class ReaderInfo
    {
        private String account;
        private String password;
        private String name;
        private String deptNo;
        private String deptName;
        private String tel;
        private int authority;
        public ReaderInfo(String account,String password,String name,String deptName,String deptNo,String tel,int authority)
        {
            this.account=account;
            this.authority=authority;
            this.password=password;
            this.deptNo=deptNo;
            this.tel=tel;
            this.name=name;
            this.deptName=deptName;
        }
        public String getAccount()
        {
            return this.account;
        }
        public void setAccount(String o)
        {
            this.account=o;
        }
        public String getPassword()
        {
            return this.password;
        }
        public void setPassword(String o)
        {
            this.password=o;
        }
        public String getName()
        {
            return this.name;
        }
        public void setName(String o)
        {
            this.name=o;
        }
        public String getDeptName()
        {
            return this.deptName;
        }
        public void setDeptName(String o)
        {
            this.deptName=o;
        }
        public String getDeptNo()
        {
            return this.deptNo;
        }
        public void setDeptNo(String o)
        {
            this.deptNo=o;
        }
        public String getTel()
        {
            return this.tel;
        }
        public void setTel(String o)
        {
            this.tel=o;
        }
        public int getAuthority()
        {
            return this.authority;
        }
        public void setAuthority(int o)
        {
            this.authority=o;
        }
    }
}
