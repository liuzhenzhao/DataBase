/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import bookborrowsystem.AddNewBook.BookInfo;
import java.awt.Component;
import java.awt.PopupMenu;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author liuzhenzhao
 */

public class AdminQueryBookController implements Initializable 
{
    
    private ArrayList<BookInfo> data=new ArrayList<BookInfo>();
    private ObservableList<BookInfo> list=FXCollections.observableArrayList();
    @FXML
    private TableView<BookInfo> tableView;
    @FXML
    private TableColumn<BookInfo,Long> bookNo;
    @FXML
    private TableColumn<BookInfo,String> bookIndex;
    @FXML
    private TableColumn<BookInfo,String> title;
    @FXML
    private TableColumn<BookInfo,String> location;
    @FXML
    private TableColumn<BookInfo,String> state;
    @FXML
    private TableColumn<BookInfo,String> author;
    @FXML
    private TableColumn<BookInfo,String> publication;
    @FXML
    private TableColumn<BookInfo,String> date;
    @FXML
    private ChoiceBox<String> selection;
    @FXML
    private TextField object;
    @FXML
    private Button query;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        try {
            // TODO
            selection.getItems().addAll("按书名查询","按索书号查询","按编号查询","按截至年份查询");
            bookNo.setCellValueFactory(new PropertyValueFactory<BookInfo,Long>("bookNo"));
            bookIndex.setCellValueFactory(new PropertyValueFactory<BookInfo,String>("bookIndex"));
            bookIndex.setCellFactory(TextFieldTableCell.<BookInfo>forTableColumn());
            bookIndex.setOnEditCommit((CellEditEvent<BookInfo, String> t) -> {
        ((BookInfo) t.getTableView().getItems().get(
            t.getTablePosition().getRow())
            ).setBookIndex(t.getNewValue());
});
            title.setCellValueFactory(new PropertyValueFactory<BookInfo,String>("title"));
            title.setCellFactory(TextFieldTableCell.<BookInfo>forTableColumn());
            title.setOnEditCommit((CellEditEvent<BookInfo, String> t) -> {
        ((BookInfo) t.getTableView().getItems().get(
            t.getTablePosition().getRow())
            ).setBookIndex(t.getNewValue());
});
            location.setCellValueFactory(new PropertyValueFactory<BookInfo,String>("location"));
            location.setCellFactory(TextFieldTableCell.<BookInfo>forTableColumn());
            location.setOnEditCommit((CellEditEvent<BookInfo, String> t) -> {
        ((BookInfo) t.getTableView().getItems().get(
            t.getTablePosition().getRow())
            ).setBookIndex(t.getNewValue());
});
            state.setCellValueFactory(new PropertyValueFactory<BookInfo,String>("state"));
            state.setCellFactory(TextFieldTableCell.<BookInfo>forTableColumn());
            state.setOnEditCommit((CellEditEvent<BookInfo, String> t) -> {
        ((BookInfo) t.getTableView().getItems().get(
            t.getTablePosition().getRow())
            ).setBookIndex(t.getNewValue());
});
            author.setCellValueFactory(new PropertyValueFactory<BookInfo,String>("author"));
            author.setCellFactory(TextFieldTableCell.<BookInfo>forTableColumn());
            author.setOnEditCommit((CellEditEvent<BookInfo, String> t) -> {
        ((BookInfo) t.getTableView().getItems().get(
            t.getTablePosition().getRow())
            ).setBookIndex(t.getNewValue());
});
            publication.setCellValueFactory(new PropertyValueFactory<BookInfo,String>("publication"));
            publication.setCellFactory(TextFieldTableCell.<BookInfo>forTableColumn());
            publication.setOnEditCommit((CellEditEvent<BookInfo, String> t) -> {
        ((BookInfo) t.getTableView().getItems().get(
            t.getTablePosition().getRow())
            ).setBookIndex(t.getNewValue());
});
            bookIndex.setCellValueFactory(new PropertyValueFactory<BookInfo,String>("bookIndex"));
            date.setCellValueFactory(new PropertyValueFactory<BookInfo,String>("year"));
            //date.setCellFactory(TextFieldTableCell.<BookInfo>forTableColumn());
            tableView.setItems(list);
            selection.setValue("按书名查询");
            ResultSet rs=null;
            Statement stmt = null;
            Connection conn = null;
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
            stmt = conn.createStatement();
            String sql="select * from book";
            rs=stmt.executeQuery(sql);
            while(rs.next())
            {
                list.add(new BookInfo(rs.getLong("No"),rs.getString("indexNo"),rs.getString("Title"),rs.getString("Location"),rs.getString("state"),
                        rs.getString("Author"),rs.getString("pub"),rs.getInt("year"),rs.getInt("month")));
            }
            tableView.setItems(list);
            if(stmt != null) 
            {  
               stmt.close();  
               stmt = null;  
            }  
            if(conn != null) 
            {  
               conn.close();  
               conn = null;  
            }
            if(rs!=null)
            {
                rs.close();
                rs = null;
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminQueryBookController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(AdminQueryBookController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void queryBookInfo(ActionEvent event) throws ClassNotFoundException, SQLException 
    {
        String temp=selection.getValue();
        String obj=object.getText();
        tableView.getItems().clear();
        String sql=null;
        if(temp.equals("按书名查询"))
        {
            sql="select * from BOOK t where t.Title like '%"+obj+"%'";
        }
        else if(temp.equals("按索书号查询"))
        {
            sql="select * from BOOK t where t.indexNo='"+obj+"'";
        }
        else if(temp.equals("按编号查询"))
        {
            sql="select * from BOOK t where t.No="+Integer.parseInt(obj);
        }
        else if(temp.equals("按截至年份查询"))
        {
            sql="select * from BOOK t where t.YEAR<="+Integer.parseInt(obj);
        }
        ResultSet rs=null;
        Statement stmt = null;
        Connection conn = null;
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        rs=stmt.executeQuery(sql);
        while(rs.next())
        {
            list.add(new BookInfo(rs.getLong("No"),rs.getString("indexNo"),rs.getString("Title"),rs.getString("Location"),rs.getString("state"),
                        rs.getString("Author"),rs.getString("pub"),rs.getInt("year"),rs.getInt("month")));
        }
        tableView.setItems(list);
        if(stmt != null) 
        {  
            stmt.close();  
            stmt = null;  
        }  
        if(conn != null) 
        {  
            conn.close();  
            conn = null;  
        }
        if(rs!=null)
        {
            rs.close();
            rs = null;
        }
    }

    @FXML
    private void popListMenu(MouseEvent event) throws ClassNotFoundException, SQLException 
    {
        ResultSet rs=null;
        Statement stmt = null;
        Connection conn = null;
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        String sql=null;
        if(event.getButton()==MouseButton.SECONDARY&&!tableView.getSelectionModel().isEmpty())
        {
           Alert alert=new Alert(Alert.AlertType.CONFIRMATION,null,new ButtonType("取消", ButtonBar.ButtonData.CANCEL_CLOSE),new ButtonType("删除此项", ButtonBar.ButtonData.OK_DONE),
            new ButtonType("提交修改", ButtonBar.ButtonData.FINISH));
           Optional<ButtonType> _buttonType = alert.showAndWait();
           if(_buttonType.get().getButtonData().equals(ButtonBar.ButtonData.OK_DONE))
           {//删除此项记录
               sql="delete from BOOK where NO="+tableView.getSelectionModel().getSelectedItem().getBookNo();
               System.out.println(sql);
               stmt.executeUpdate(sql);
           }
           else if(_buttonType.get().getButtonData().equals(ButtonBar.ButtonData.FINISH))
           {//修改此项记录
               Long no=tableView.getSelectionModel().getSelectedItem().getBookNo();
               String indexNo=tableView.getSelectionModel().getSelectedItem().getBookIndex();
               String title=tableView.getSelectionModel().getSelectedItem().getTitle();
               String location=tableView.getSelectionModel().getSelectedItem().getLocation();
               String state=tableView.getSelectionModel().getSelectedItem().getState();
               String author=tableView.getSelectionModel().getSelectedItem().getAuthor();
               String pub=tableView.getSelectionModel().getSelectedItem().getPublication();
               int date=tableView.getSelectionModel().getSelectedItem().getYear();
               sql="update BOOK set (NO,INDEXNO,TITLE,LOCATION,STATE,AUTHOR,PUB,YEAR)=(select "+no+",'"+indexNo+"',"
                       +"'"+title+"','"+location+"','"+state+"','"+author+"','"+pub+"',"+date+" from dual) where NO="+no;
               System.out.println(sql);
               stmt.executeUpdate(sql);
           }
           if(stmt != null) 
           {  
                stmt.close();  
                stmt = null;  
            }  
            if(conn != null) 
            {  
                conn.close();  
                conn = null;  
            }
            if(rs!=null)
            {
                rs.close();
                rs = null;
            }
        }
    }

}
