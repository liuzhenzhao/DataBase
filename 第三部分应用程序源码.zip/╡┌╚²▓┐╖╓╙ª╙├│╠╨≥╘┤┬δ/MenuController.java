/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author liuzhenzhao
 */
public class MenuController implements Initializable {

    @FXML
    private Button queryBook;
    @FXML
    private Button personalInfo;
    @FXML
    private Button borrowRecord;

    /**
     * Initializes the controller class.
     */
     //Stage stage=new Stage(); 
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
   
    }    

    @FXML
    private void OnQueryBookButton(ActionEvent event) throws Exception 
    {
        bookborrowsystem.CreateUI ui=new CreateUI("readerSearchBook_1.fxml");
        ui.showWindow();
    }

    @FXML
    private void OnPersonalInfoButton(ActionEvent event) throws Exception 
    {
        bookborrowsystem.CreateUI ui=new CreateUI("personalInfo.fxml");
        ui.showWindow();
    }

    @FXML
    private void OnBorrowRecordButton(ActionEvent event) throws Exception 
    {
        bookborrowsystem.CreateUI ui=new CreateUI("borrowRecord.fxml");
        ui.showWindow();
    }
}
