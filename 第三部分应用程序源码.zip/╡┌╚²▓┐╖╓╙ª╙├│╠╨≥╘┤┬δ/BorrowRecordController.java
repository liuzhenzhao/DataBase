/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.InvalidationListener;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import static javafx.scene.input.KeyCode.T;
import javafx.scene.input.MouseEvent;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author liuzhenzhao
 */
public class BorrowRecordController implements Initializable 
{
    private ArrayList<BorrowRecordController.RecordItem> data=new ArrayList<BorrowRecordController.RecordItem>();
    private ObservableList<BorrowRecordController.RecordItem> list=FXCollections.observableArrayList();
    @FXML
    private TableView<RecordItem> RecordTable;
    @FXML
    private TableColumn<RecordItem,String> title;
    @FXML
    private TableColumn<RecordItem,Long> No;
    @FXML
    private TableColumn<RecordItem,String> indexNo;
    @FXML
    private TableColumn<RecordItem,String> state;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        try {
            // TODO
            title.setCellValueFactory(new PropertyValueFactory<BorrowRecordController.RecordItem,String>("title"));
            No.setCellValueFactory(new PropertyValueFactory<BorrowRecordController.RecordItem,Long>("No"));
            indexNo.setCellValueFactory(new PropertyValueFactory<BorrowRecordController.RecordItem,String>("indexNo"));
            state.setCellValueFactory(new PropertyValueFactory<BorrowRecordController.RecordItem,String>("state"));
            RecordTable.setItems(list);
            String temp=bookborrowsystem.FXMLController._readerAccount;
            String sql="select t2.Title as Title,t2.No as No,t1.ReturnDate as State,t2.indexNo as indexNo "
                    + "from borrow t1,Book t2 where t1.ReaderAccount='"+temp+"' and t1.BookNo=t2.No";
            ResultSet rs = null;
            Statement stmt = null;
            Connection conn = null;
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
            stmt = conn.createStatement();
            rs=stmt.executeQuery(sql);
            while(rs.next())
            {
                list.add(new RecordItem(rs.getString("Title"),rs.getLong("No"),
                        rs.getString("indexNo"),"还书日期"+rs.getString("State")));
            }
            RecordTable.setItems(list);
            if(stmt != null)
            {
                stmt.close();
                stmt = null;  
            }
            if(conn != null)
            {
                conn.close();
                conn = null;
            }
            if(rs!=null)
            {
                rs.close();
                rs = null;
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BorrowRecordController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(BorrowRecordController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    

    @FXML
    private void popSubWindow(MouseEvent event) throws ClassNotFoundException, SQLException 
    {
        Alert alert=new Alert(Alert.AlertType.CONFIRMATION,"是否续借该图书?",new ButtonType("否", ButtonBar.ButtonData.NO),
                new ButtonType("是", ButtonBar.ButtonData.YES));
        alert.setTitle("续借图书");
        Optional<ButtonType> _buttonType = alert.showAndWait();
        if(_buttonType.get().getButtonData().equals(ButtonBar.ButtonData.YES))
        {//confirm reborrow the book
            Long temp=RecordTable.getSelectionModel().getSelectedItem().No;
            String sql="update Borrow set (reborrow,Returndate)=(select 1,Returndate + interval '30' day from dual) " +
"                where not exists " +
"	       (select * from Borrow t1,Book t2 " +
"               where t1.BookNo=t2.No " +
"               and   t1.Reborrow=1) " +
"               and   borrow.BOOKNO="+temp;
            //System.out.println(sql);
            ResultSet rs = null;
            Statement stmt = null;
            Connection conn = null;
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
            stmt = conn.createStatement();
            rs=stmt.executeQuery(sql);
            if(stmt != null) 
            {  
                stmt.close();  
                stmt = null;  
            }  
            if(conn != null) 
            {  
                conn.close();  
                conn = null;  
            }
            if(rs!=null)
            {
                rs.close();
                rs = null;
            }
        }
        else 
        {//not reborrow the book
            ;
        }
    }
    public class RecordItem
    {
        private String title;
        private  Long No;
        private String indexNo;
        private String state;
        public RecordItem(String title,Long No,String indexNo,String state)
        {
            this.title=title;
            this.No=No;
            this.indexNo=indexNo;
            this.state=state;
        }
        public String getTitle()
        {
            return this.title;
        }
        public void setTitle(String title)
        {
        }
        public Long getNo()
        {
            return this.No;
        }
        public void setNo(Long No)
        {}
        public String getIndexNo()
        {
            return this.indexNo;
        }
        public void setIndexNo(String indexNo)
        {}
        public String getState()
        {
            return this.state;
        }
        public void setSate(String state)
        {}
    }
}
