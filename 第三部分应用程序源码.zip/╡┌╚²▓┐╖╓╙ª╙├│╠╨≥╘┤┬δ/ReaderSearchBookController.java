/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author liuzhenzhao
 *//*
*/
public class ReaderSearchBookController implements Initializable 
{
    private ArrayList<BookItem> data=new ArrayList<BookItem>();
    private ObservableList<BookItem> list=FXCollections.observableArrayList();
    @FXML
    private ChoiceBox<?> choice;
    @FXML
    private TextField editObject;
    @FXML
    private Button commit;
    @FXML
    private TableView<BookItem> tableView;
    @FXML
    private TableColumn<BookItem,String> title;
    @FXML
    private TableColumn<BookItem,String> author;
    @FXML
    private TableColumn<BookItem,String> pub;
    @FXML
    private TableColumn<BookItem,String> date;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
        ArrayList item=new ArrayList();
        item.add("按书名查询");
        item.add("按作者查询");
        item.add("按索书号查询");
        item.add("查询所有");
        choice.getItems().addAll(item);
        title.setCellValueFactory(new PropertyValueFactory<BookItem,String>("bookname"));
        author.setCellValueFactory(new PropertyValueFactory<BookItem,String>("bookauthor"));
        pub.setCellValueFactory(new PropertyValueFactory<BookItem,String>("publication"));
        date.setCellValueFactory(new PropertyValueFactory<BookItem,String>("pubdate"));
        tableView.setItems(list);
    }    

    @FXML
    private void commit(ActionEvent event) throws ClassNotFoundException, SQLException
    {
        tableView.getItems().clear();
        if(choice.getValue()==null/*||editObject.getText().length()==0*/)
        {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setContentText("请选择查询方式");
            alert.show();
        }
        else
        {
            ResultSet rs = null;
            Statement stmt = null;
            Connection conn = null;
            String temp=editObject.getText();
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
            stmt = conn.createStatement();
            if(choice.getValue().equals("按书名查询"))
            {
                String sql="select DISTINCT Title,Author,pub,Year,Month from Book where Title like '%"+temp+"%'";
                rs=stmt.executeQuery(sql);
            }
            else if(choice.getValue().equals("按作者查询"))
            {
                String sql="select DISTINCT Title,Author,pub,Year,Month from Book where Author like '%"+temp+"%'";
                rs = stmt.executeQuery(sql);
            }
            else if(choice.getValue().equals("按索书号查询"))
            {//按索书号查询
                String sql="select DISTINCT Title,Author,pub,Year,Month from Book where indexNo like '"+temp+"%'";
                rs = stmt.executeQuery(sql);
            }
            else
            {
                String sql="select DISTINCT Title,Author,pub,Year,Month from Book";
                rs = stmt.executeQuery(sql);
            }
            while(rs.next())
            {
                list.add(new BookItem(rs.getString("Title"),rs.getString("Author"),
                rs.getString("pub"),rs.getString("Year")+"."+rs.getString("Month")));
            }
            tableView.setItems(list);
            if(stmt != null) 
            {  
               stmt.close();  
               stmt = null;  
            }  
            if(conn != null) 
            {  
               conn.close();  
               conn = null;  
            }
            if(rs!=null)
            {
                rs.close();
                rs = null;
            }
        }
    }

    @FXML
    private void detailOfBook(MouseEvent event) throws ClassNotFoundException, SQLException 
    {
        ResultSet rs = null;
        Statement stmt = null;
        Connection conn = null;
        String s1=tableView.getSelectionModel().getSelectedItem().bookname.get();
        String s2=tableView.getSelectionModel().getSelectedItem().bookauthor.get();
        String s3=tableView.getSelectionModel().getSelectedItem().publication.get();
        //String s4=tableView.getSelectionModel().getSelectedItem().pubdate.get();
        String sql="select No,indexNo,Location,State,Title,Author from Book t where t.Title='"+s1+"' and t.Author='"+s2+"' and"
                + " t.pub='"+s3+"'";
         System.out.println(sql);
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        rs=stmt.executeQuery(sql);
        Stage _stage=new Stage();
        TableView<DetailItem> _table=new TableView<DetailItem>();
        ObservableList<DetailItem> _data = FXCollections.observableArrayList();
        Scene _scene=new Scene(_table);
        _stage.setScene(_scene);
        _stage.setTitle("馆藏信息");
        //_stage.setWidth(600);  
        //_stage.setHeight(500);
        _stage.setMaximized(true);
        TableColumn firstCol = new TableColumn("书名");
        firstCol.setMinWidth(200);  
        firstCol.setCellValueFactory(  
                new PropertyValueFactory<DetailItem, String>("bookname"));
        TableColumn secondCol = new TableColumn("作者");  
        secondCol.setMinWidth(200);  
        secondCol.setCellValueFactory(  
                new PropertyValueFactory<DetailItem, String>("bookauthor"));
        TableColumn thirdCol = new TableColumn("编号");  
        thirdCol.setMinWidth(200);  
        thirdCol.setCellValueFactory(  
                new PropertyValueFactory<DetailItem,Long>("bookNo"));
        TableColumn forthCol = new TableColumn("馆藏地点");  
        forthCol.setMinWidth(200);  
        forthCol.setCellValueFactory(  
                new PropertyValueFactory<DetailItem,String>("location"));
        TableColumn fifthCol = new TableColumn("状态");  
        fifthCol.setMinWidth(200);  
        fifthCol.setCellValueFactory(  
                new PropertyValueFactory<DetailItem,String>("state"));
        TableColumn sixthCol = new TableColumn("索书号");  
        sixthCol.setMinWidth(200);  
        sixthCol.setCellValueFactory(  
                new PropertyValueFactory<DetailItem,String>("indexNo"));
        _table.getColumns().addAll(firstCol,secondCol,thirdCol,forthCol,fifthCol,sixthCol);
        //_table.addEventHandler(MouseEvent.MOUSE_CLICKED,new TableClickEvent(_table,true));
        _stage.show();
        while(rs.next())
        {
            /*System.out.println(rs.getString("Title")+"|"+rs.getString("Author")+"|"+rs.getLong("No")+"|"+
            rs.getString("Location")+"|"+rs.getString("State")+"|"+rs.getString("indexNo"));*/
            _data.addAll(new DetailItem(rs.getString("Title"),rs.getString("Author"),rs.getLong("No"),
            rs.getString("Location"),rs.getString("State"),rs.getString("indexNo")));
        }
        _table.setItems(_data);
        _table.addEventHandler(MouseEvent.MOUSE_CLICKED,new TableClickEvent(_table,true));
        if(stmt != null) 
        {  
            stmt.close();  
            stmt = null;  
        }  
        if(conn != null) 
        {  
            conn.close();  
            conn = null;  
        }
        if(rs!=null)
        {
            rs.close();
            rs = null;
        }
    }
    public static class BookItem
    {
        private final SimpleStringProperty bookname;
        private final SimpleStringProperty bookauthor;
        private final SimpleStringProperty publication;
        private final SimpleStringProperty pubdate;
        public BookItem(String title,String author,String pub,String date)
        {
            this.bookname=new SimpleStringProperty(title);
            this.bookauthor=new SimpleStringProperty(author);
            this.publication=new SimpleStringProperty(pub);
            this.pubdate=new SimpleStringProperty(date);
        }
        public String getBookname()
        {
       // System.out.println("call me");
            return this.bookname.get();
        }
        public void setBookname(String title)
        {
            this.bookname.set(title);
        }
        public String getBookauthor()
        {
            return this.bookauthor.get();
        }
        public void setBookauthor(String author)
        {
            this.bookauthor.set(author);
        }
        public String getPublication()
        {
            return this.publication.get();
        }
        public void setPublication(String pub)
        {
            this.publication.set(pub);
        }
        public String getPubdate()
        {
             return this.pubdate.get();   
        }
        public void setPubdate(String date)
        {
            this.pubdate.set(date);
        }
}
    public static class DetailItem
    {
        private final SimpleStringProperty bookname;
        private final SimpleStringProperty bookauthor;
        private final SimpleLongProperty bookNo;
        private final SimpleStringProperty location;
        private final SimpleStringProperty state;
        private final SimpleStringProperty indexNo;
        public DetailItem(String title,String author,Long no,String location,String state,String indexNo)
        {
            this.bookname=new SimpleStringProperty(title);
            this.bookauthor=new SimpleStringProperty(author);
            this.bookNo=new SimpleLongProperty(no);
            this.location=new SimpleStringProperty(location);
            this.state=new SimpleStringProperty(state);
            this.indexNo=new SimpleStringProperty(indexNo);
        }
        public String getBookname()
        {
            return this.bookname.get();
        }
        public void setBookname(String title)
        {
            this.bookname.set(title);
        }
        public String getBookauthor()
        {
            return this.bookauthor.get();
        }
        public void setBookauthor(String author)
        {
            this.bookauthor.set(author);
        }
        public Long getBookNo()
        {
            return this.bookNo.get();
        }
        public void setBookNo(Long o)
        {
            this.bookNo.set(o);
        }
        public String getLocation()
        {
            return this.location.get();   
        }
        public void setLacation(String o)
        {
            this.location.set(o);
        }
        public String getState()
        {
            return this.state.get();   
        }
        public void setState(String o)
        {
            this.state.set(o);
        }
        public String getIndexNo()
        {
            return this.indexNo.get();   
        }
        public void setIndexNo(String o)
        {
            this.indexNo.set(o);
        }
    }
}
