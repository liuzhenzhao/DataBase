create table SHOW(
FID int not null,
TID int not null,
PRICE int,
YEAR int,
MONTH int constraint SHOW_MONTH_CONS check(MONTH between 1 and 12),
constraint SHOW_PRIMARYKEY_CONS primary key(FID,TID),
constraint SHOW_FOREIGNKEY1_CONS foreign key(FID) references FILM on delete cascade,
constraint SHOW_FOREIGNKEY2_CONS foreign key(TID) references THEATER on delete cascade);
insert into SHOW values(1,3,20,2017,3);
insert into SHOW values(1,5,20,2017,3);
insert into SHOW values(1,4,30,2017,6);
insert into SHOW values(3,3,30,2018,3);
insert into SHOW values(4,2,25,2017,12);
insert into SHOW values(2,1,29,2018,2);
insert into SHOW values(2,2,29,2017,6);
insert into SHOW values(7,1,80,2016,2);
insert into SHOW values(7,5,80,2016,3);
insert into SHOW values(7,4,80,2017,3);
insert into SHOW values(7,6,80,2017,8);
insert into SHOW values(7,2,80,2016,8);
insert into SHOW values(7,3,80,2016,2);
insert into SHOW values(9,1,45,2017,2);
insert into SHOW values(10,2,55,2017,10);
insert into SHOW values(11,2,75,2013,11);
insert into SHOW values(11,3,75,2013,11);
insert into SHOW values(11,5,75,2013,11);
insert into SHOW values(12,5,75,2014,12);
insert into SHOW values(12,1,65,2014,12);
select * from SHOW s,FILM f,THEATER t where s.FID=f.FID and s.TID=t.TID 
and f.FNAME='战狼' and s.YEAR=2017 and t.TAREA='洪山区' order by s.MONTH DESC; 

select f.FID,f.FNAME,f.DNAME from FILM f where not exists 
(select * from SHOW s where s.FID=f.FID and s.YEAR<2018);

