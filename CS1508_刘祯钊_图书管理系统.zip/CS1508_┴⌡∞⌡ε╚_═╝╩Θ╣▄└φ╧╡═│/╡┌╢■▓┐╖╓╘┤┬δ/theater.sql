create table THEATER(
TID int not null,
TNAME char(20),
TAREA char(20) check(TAREA in('洪山区','武昌区','江夏区','汉口区')),
ADDRESS char(30),
primary key(TID));
insert into THEATER values(1,'一号影院','洪山区','珞喻路1号');
insert into THEATER values(2,'二号影院','汉口区','解放路2号');
insert into THEATER values(3,'三号影院','武昌区','武珞路3号');
insert into THEATER values(4,'四号影院','江夏区','熊廷弼路4号');
insert into THEATER values(5,'五号影院','洪山区','珞喻路5号');
insert into THEATER values(6,'六号影院','洪山区','珞喻路6号');