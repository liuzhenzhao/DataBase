create table ACTOR(
ACTID int not null,
ANAME char(30),
SEX char(2),
BYEAR int,
primary key(ACTID));
insert into ACTOR values(1,'黄晓明','M',null);
insert into ACTOR values(2,'刘亦菲','F',1988);
insert into ACTOR values(3,'姜文','M',1963);
insert into ACTOR values(4,'巩俐','F',1965);
insert into ACTOR values(5,'陶泽如','M',1953);
insert into ACTOR values(6,'张天爱','F',1990);
insert into ACTOR values(7,'黄轩','M',1985);
insert into ACTOR values(8,'张涵予','M',1964);
insert into ACTOR values(9,'吴京','M',1982);
insert into ACTOR values(10,'周润发','M',1975);
insert into ACTOR values(11,'周星驰','M',1980);
insert into ACTOR values(12,'凯丽.费雪','F',1956);
create table YOUNG_ACTOR as (select * from ACTOR where BYEAR>1990 or BYEAR=1990);
delete from ACTOR where BYEAR is null;
update ACTOR set BYEAR=1987 where ANAME='刘亦菲';
