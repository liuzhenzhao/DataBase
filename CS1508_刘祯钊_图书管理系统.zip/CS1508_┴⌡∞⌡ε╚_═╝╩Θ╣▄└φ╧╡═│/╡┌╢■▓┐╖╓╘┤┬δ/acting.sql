create table ACTIN(
ACTID int not null,
FID int not null,
ISLEADING char(1) constraint ACTIN_ISLEADING_CONS check(ISLEADING in('Y','N')),
GRADE int constraint ACTIN_GRADE_CONS check(GRADE between 0 and 100),
constraint ACTIN_PRIMARYKEY_CONS primary key(ACTID,FID),
constraint ACTIN_FOREIGNKEY1_CONS foreign key(ACTID) references ACTOR(ACTID) on delete cascade,
constraint ACTIN_FOREIGNKEY2_CONS foreign key(FID) references FILM(FID) on delete cascade);
insert into ACTIN values(5,1,'N',8);
insert into ACTIN values(4,2,'N',9);
insert into ACTIN values(7,3,'Y',7);
insert into ACTIN values(8,4,'N',9);
insert into ACTIN values(4,8,'N',8);
insert into ACTIN values(3,8,'N',8);
insert into ACTIN values(10,9,'Y',75);
insert into ACTIN values(2,10,'Y',78);
insert into ACTIN values(9,7,'Y',90);
insert into ACTIN values(6,3,'N',70);
insert into ACTIN values(12,11,'Y',null);
insert into ACTIN values(12,12,'Y',null);
create view LEADEING_80(ACTID,ANAME,BYEAR,LEADEING_FILM_SUM,HIGNCORE) as select s2.ACTID,s2.ANAME,s2.BYEAR,COUNT(s1.FID),MAX(s1.GRADE) 
                  from ACTIN s1,ACTOR s2 where s2.ACTID=s1.ACTID and s1.ISLEADING='Y' and s2.BYEAR>1980 group by s2.ACTID,s2.ANAME,s2.BYEAR;