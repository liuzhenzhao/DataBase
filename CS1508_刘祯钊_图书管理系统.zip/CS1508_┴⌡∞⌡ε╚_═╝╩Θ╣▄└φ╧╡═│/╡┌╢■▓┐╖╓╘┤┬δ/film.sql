create table FILM(
	FID int not null,
	FNAME char(30),
	FTYPE char(10),
	DNAME char(30),
	length int,
	IS3D char(1) not null check(IS3D in('Y','N')),
	GRADE int check(GRADE between 0 and 100),
	primary key(FID));
insert into FILM values(1,'百鸟朝凤','文艺','吴天明',103,'N',80);
insert into FILM values(2,'红高粱','文艺','张艺谋',120,'N',90);
insert into FILM values(3,'妖猫传','奇幻','陈凯歌',113,'Y',70);
insert into FILM values(4,'红海行动','战争','林超贤',120,'N',90);
insert into FILM values(5,'大唐玄奘','历史','霍建起',130,'Y',70);
insert into FILM values(6,'紫日','战争','冯小宁',150,'N',92);
insert into FILM values(7,'战狼','战争','吴京',130,'Y',90);
insert into FILM values(8,'大红灯笼高高挂','文艺','张艺谋',120,'N',80);
insert into FILM values(9,'英雄本色','枪战','吴宇森',116,'N',75);
insert into FILM values(10,'三生三世十里桃花','爱情','赵小丁',109,'Y',78);
insert into FILM values(11,'星球大战1','科幻','乔治.卢卡斯',129,'N',null);
insert into FILM values(12,'星球大战2','科幻','乔治.卢卡斯',115,'N',null);
insert into FILM values(13,'黄河绝恋','战争','冯小宁',150,'N',86);
create or replace trigger trig_FILM
	before insert on FILM
	for each row
	when(new.DNAME='周星驰')
	begin
	   :new.FTYPE:='喜剧';
	end;
	/
insert into FILM values(14,'美人鱼','奇幻','周星驰',110,'Y',90);