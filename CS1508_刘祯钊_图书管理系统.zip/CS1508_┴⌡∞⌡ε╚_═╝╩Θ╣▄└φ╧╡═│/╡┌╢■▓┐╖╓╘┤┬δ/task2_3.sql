#1
select * from SHOW s,FILM f,THEATER t where s.FID=f.FID and s.TID=t.TID 
and f.FNAME='战狼' and s.YEAR=2017 and t.TAREA='洪山区' order by s.MONTH DESC; 

#2
select * from FILM t1
         where not exists
               (select * from FILM t2,ACTIN t3
                         where t2.FID=t3.FID
                         and   t1.FID=t3.FID) order by FTYPE,GRADE DESC;
#3
select f.FID,f.FNAME,f.DNAME from FILM f where not exists 
(select * from SHOW s where s.FID=f.FID and s.YEAR<2018);
#4
select FID from SHOW s group by s.FID having count(TID)=(select count(*) from THEATER);
#5
select FID,FNAME,DNAME,GRADE from FILM where GRADE not between 80 and 90;
#6
select DNAME,min(GRADE) as minSCores,max(GRADE) as maxScores from FILM group by DNAME;
#7
select DNAME,count(FID) as film_num from FILM group by DNAME having count(FID)>=2;
#8
select DNAME,count(FID) as film_num,AVG(GRADE) as avgScores 
       from FILM where GRADE>=80
       group by DNAME having count(FID)>=2;
#9
select DISTINCT f.DNAME,a.ACTID,a.ANAME from FILM f,ACTOR a,ACTIN s where f.FID=s.FID and s.ACTID=a.ACTID
and f.DNAME in (select DNAME from FILM group by DNAME having count(FID)>=2);
#10
select ANAME,AVG(GRADE) from ACTIN t1,ACTOR t2  where t1.ACTID=t2.ACTID group by t1.ACTID,t2.ANAME;
#11
select MIN(YEAR),MIN(MONTH) as minMonth from SHOW t1,FILM t2 
                                        where t1.FID=t2.FID and t2.GRADE>=90
                                        and YEAR=
                                        (select MIN(YEAR) from SHOW t1,FILM t2 
                                        	where t1.FID=t2.FID and t2.GRADE>=90);
 #12
select DISTINCT t3.FID,t3.FNAME,t4.YEAR,t4.MONTH 
       from FILM t3,SHOW t4
       where t3.FID=t4.FID
       and   (t4.YEAR*12+t4.MONTH)
       =(select min(t2.YEAR*12+t2.MONTH)
                 from FILM t1,SHOW t2 
                 where GRADE>=90
                 and   t1.FID=t2.FID
                 and   t3.FID=t2.FID
                 group by t1.FID,t1.FNAME);
#13
select FID,count(*) as times from SHOW group by FID;
#14
select DNAME from FILM where FTYPE in ('动作','警匪','枪战');
#15
select t1.FID as FID,t1.FNAME as FNAME,t3.TNAME as TNAME,t2.YEAR as Year,t2.MONTH as Month from FILM t1,SHOW t2,THEATER t3 where t1.FID=t2.FID 
                                       and t2.TID=t3.TID
                                       and t1.FNAME like '战狼%';
#16
select DISTINCT t1.TID from SHOW t1,SHOW t2
              where t1.FID=t2.FID
              and   t1.YEAR=t2.YEAR
              and   t1.MONTH=t2.MONTH
              and   t1.TID <>t2.TID
              and   t1.FID between 1 and 2;
#17
(select ACTID,ANAME from ACTOR) minus
                            (select t1.ACTID,t1.ANAME from ACTOR t1,ACTIN t2 where t2.GRADE<85
                            	                                             and t1.ACTID=t2.ACTID);
#18
select ANAME from ACTOR t1 
             where not exists
                   (select ACTID,FID from ACTIN t2 
                   	                 where not exists
                                           (select t3.FID from ACTIN t4,FILM t3
                                                          where t3.DNAME='吴宇森'
                                                          and t3.FID=t4.FID
                                                          and t2.FID=t3.FID
                                                          and t1.ACTID=t4.ACTID));
#19
select DISTINCT t1.ACTID as ACTID,t1.ANAME as ANAME,t3.FNAME as FNAME 
         from ACTOR t1 left join ACTIN t2 on t1.ACTID=t2.ACTID 
                       left join FILM t3 on t2.FID=t3.FID
                       order by t1.ACTID;
#20
select t1.FID as ID,t1.FNAME as NAME from FILM t1,SHOW t2
                                     where t1.FID=t2.FID
                                     and   t1.GRADE is null
                                     group by t1.FID,t1.FNAME having count(*)>=3;



exp liuzhao/liuzhao666@XE file=D:\OracleDataBase\Oracle\app\oracle\oradata\export\lab.dmp ignore=y full=y
create temporary tablespace user_temp 
tempfile 'D:\OracleDataBase\Oracle\app\oracle\oradata\db\user_temp.dbf' 
size 50m 
autoextend on 
next 50m maxsize 20480m 
extent management local; 
create tablespace user_data 
logging 
datafile 'D:\OracleDataBase\Oracle\app\oracle\oradata\db\user_temp01.dbf' 
size 50m 
autoextend on 
next 50m maxsize 20480m 
extent management local; 
imp liu/liu666@XE full=y file=D:\OracleDataBase\Oracle\app\oracle\oradata\export\lab.dmp ignore=y

