/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.stage.Popup;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author liuzhenzhao
 */
public class FXMLController implements Initializable {

    /**
     *
     */
    public static String _readerAccount;
    public static String _adminAccount;
    @FXML
    private TextField readerAccount;
    @FXML
    private TextField readerPassword;
    @FXML
    private Button okReaderLog;
    @FXML
    private Tab readerLog;
    @FXML
    private Tab managerLog;
    @FXML
    private TextField managerAccount;
    @FXML
    private TextField managerPassword;
    @FXML
    private Button okManagerLog;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        //TODO
    }    

    @FXML
    private void login(ActionEvent event) throws ClassNotFoundException, SQLException, IOException, Exception 
    {
        if(readerLog.isSelected())
        {
            if(readerAccount.getText().length()==0)
            {
                System.out.println("账号不能为空");      
                Alert alert=new Alert(AlertType.ERROR);
                alert.setTitle("Error Occurs");
                alert.setContentText("账号不能为空");
                alert.show();
            }
            else if(readerPassword.getText().length()==0)
            {
                Alert alert=new Alert(AlertType.ERROR);
                alert.setTitle("Error Occurs");
                alert.setContentText("密码不能为空");
                alert.show();
            }
            else
            {
                String _account=readerAccount.getText();
                String _password=readerPassword.getText();
                if(!Identify(_account,_password,true))
                {
                    Alert alert=new Alert(AlertType.ERROR);
                    alert.setTitle("Error Occurs");
                    alert.setContentText("账号或密码错误");
                    alert.show();
                }
                else
                {
                //进入下一个界面
                    _readerAccount=readerAccount.getText();
                    readerAccount.setDisable(true);
                    readerPassword.setDisable(true);
                    okReaderLog.setDisable(true);
                    bookborrowsystem.CreateUI ui=new CreateUI("readerMenu.fxml");
                    ui.showWindow();
                
                }
            }
        }
        else
        {
            if(managerAccount.getText()==null)
            {
                Alert alert=new Alert(AlertType.ERROR);
                alert.setTitle("Error Occurs");
                alert.setContentText("账号不能为空");
                alert.show();
            }
            else if(managerPassword.getText()==null)
            {
                Alert alert=new Alert(AlertType.ERROR);
                alert.setTitle("Error Occurs");
                alert.setContentText("密码不能为空");
                alert.show();
            }
            else
            {
                String _account=managerAccount.getText();
                String _password=managerPassword.getText();
                if(!Identify(_account,_password,false))
                {
                    Alert alert=new Alert(AlertType.ERROR);
                    alert.setTitle("Error Occurs");
                    alert.setContentText("账号或密码错误");
                    alert.show();
                }
                else
                {
                //进入下一个界面
                    _adminAccount=managerAccount.getText();
                    System.out.println("OK");
                    bookborrowsystem.CreateUI ui=new CreateUI("adminMenu.fxml");
                    ui.showWindow();
                }
            }
        }
    }
    private boolean Identify(String account,String password,boolean IS_Reader) throws ClassNotFoundException, SQLException
    {
        ResultSet rs = null;
        Statement stmt = null;
        Connection conn = null;     
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        if(IS_Reader)
        {
           String sql="select Account,Password from Reader where Account=\'"+account+"\' and Password=\'"+password+"\'";
           System.out.println(sql);
           rs = stmt.executeQuery(sql);
        }
        else
        {
            String sql="select Account,Password from Admin where Account=\'"+account+"\' and Password=\'"+password+"\'";
            System.out.println(sql);
            rs = stmt.executeQuery(sql);

        }
        while(rs.next())
        {
            System.out.println("succeed in loging");
            if(stmt != null) 
            {  
               stmt.close();  
               stmt = null;  
            }  
            if(conn != null) 
            {  
               conn.close();  
               conn = null;  
            }
            if(rs!=null)
            {
               rs.close();
               rs = null;
            }
            return true;
        }
        if(stmt != null) 
        {  
           stmt.close();  
           stmt = null;  
        }  
        if(conn != null) 
        {  
           conn.close();  
           conn = null;  
        }
        if(rs!=null)
        {
            rs.close();
            rs = null;
        }
        return false;
    }
}
