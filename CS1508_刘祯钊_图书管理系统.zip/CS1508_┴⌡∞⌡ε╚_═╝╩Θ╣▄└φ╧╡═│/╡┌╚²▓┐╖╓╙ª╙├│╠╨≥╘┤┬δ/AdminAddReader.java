/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author liuzhenzhao
 */
public class AdminAddReader implements Initializable {

    @FXML
    private TextField editAccount;
    @FXML
    private TextField editPassword;
    @FXML
    private TextField editName;
    @FXML
    private ChoiceBox<String> editDept;
    @FXML
    private TextField editTel;
    @FXML
    private Button OK;
    @FXML
    private Button Cancle;
    @FXML
    private Pane addReaderPane;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
        editDept.getItems().addAll("1 (计算机学院)","2 (自动化学院)","3 (光电学院)","4 (电信学院)","5 (电气学院)","6 (机械学院)");
        editDept.setValue("1 (计算机学院)");
    }    

    @FXML
    private void OK_Cmmit(ActionEvent event) throws ClassNotFoundException, SQLException 
    {
        if(anyItemEmpty())
        {
            Alert alert=new Alert(Alert.AlertType.WARNING);
            alert.setTitle("警告");
            alert.setContentText("有未填写项，请认真填写!");
            alert.showAndWait();
            return;
        }
        int rs=0;
        Statement stmt = null;
        Connection conn = null;
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        String sql=null;
        String _account=editAccount.getText();
        String _password=editPassword.getText();
        String _name=editName.getText();
        String []deptno=editDept.getValue().split(" ");
        int _deptno=Integer.parseInt(deptno[0]);
        String _tel=editTel.getText();
        int _authority=1;
        sql="insert into READER select '"+_account+"','"+_password+"','"+_name+"',"+_deptno+",'"+_tel+"',"+_authority+" from "
                + "dual where not exists (select * from READER t where t.ACCOUNT='"+_account+"')";
        System.out.println(sql);
        rs=stmt.executeUpdate(sql);
        if(stmt != null) 
        {  
            stmt.close();  
            stmt = null;  
        }  
        if(conn != null) 
        {  
            conn.close();  
            conn = null;  
        }
        if(rs==0)
        {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setTitle("添加出错");
            alert.setContentText("插入出错，可能该读者已经存在!");
            alert.showAndWait();
        }    
        bookborrowsystem.CreateUI.stage.hide();
    }

    @FXML
    private void CancleAll(ActionEvent event) 
    {
        bookborrowsystem.CreateUI.stage.close();
    }
    private boolean anyItemEmpty()
    {
        return ((editAccount.getText().equals(""))||(editPassword.getText().equals(""))||(editName.getText().equals(""))
                ||(editDept.getValue().equals(""))||(editTel.getText().equals("")));
    }
}
