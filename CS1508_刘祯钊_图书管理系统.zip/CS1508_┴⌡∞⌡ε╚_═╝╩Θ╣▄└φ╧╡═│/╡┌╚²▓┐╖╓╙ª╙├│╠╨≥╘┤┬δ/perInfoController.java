/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author liuzhenzhao
 */
public class perInfoController implements Initializable {

    @FXML
    private TextField Account;
    @FXML
    private TextField Name;
    @FXML
    private TextField Dept;
    @FXML
    private TextField Tel;
    @FXML
    private TextField number;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        try {
            // TODO
            ResultSet rs = null;
            Statement stmt = null;
            Connection conn = null;
            String temp=bookborrowsystem.FXMLController._readerAccount;
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
            stmt = conn.createStatement();
            String sql1="Select count(*) as sum from Borrow t where t.ReaderAccount='"+temp+"'";
            rs = stmt.executeQuery(sql1);
            while(rs.next())
            {
                number.setText(""+rs.getInt("SUM"));
            }
            String sql2="select t1.Name as ReaderName,t1.Account as Account,t2.Name as Dept,t1.Tel as Tel"
                    + " from Reader t1,Dept t2 where t1.DeptNo=t2.No and t1.Account='"+temp+"'";
            rs = stmt.executeQuery(sql2);
            while(rs.next())
            {
                Account.setText(rs.getString("Account"));
                Name.setText(rs.getString("ReaderName"));
                Dept.setText(rs.getString("Dept"));
                Tel.setText(rs.getString("Tel"));
            }
            if(stmt != null) 
            {  
               stmt.close();  
               stmt = null;  
            }  
            if(conn != null) 
            {  
               conn.close();  
               conn = null;  
            }
            if(rs!=null)
            {
                rs.close();
                rs = null;
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(perInfoController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(perInfoController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }    
    
}
