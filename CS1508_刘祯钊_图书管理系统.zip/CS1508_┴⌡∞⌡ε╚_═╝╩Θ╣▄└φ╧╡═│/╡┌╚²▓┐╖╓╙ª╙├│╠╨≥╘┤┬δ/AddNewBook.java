/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author liuzhenzhao
 */

public class AddNewBook implements Initializable {

    @FXML
    private TextField bookNo;
    @FXML
    private TextField bookIndex;
    @FXML
    private TextField title;
    @FXML
    private ChoiceBox<String> location;
    @FXML
    private TextField author;
    @FXML
    private TextField publication;
    @FXML
    private DatePicker pubdate;
    @FXML
    private Button continueAdd;
    @FXML
    private Button cancle;
    @FXML
    private Button finish;
    @FXML
    private Button back;
    private List<BookInfo> itemlist;
    private int cursor;
    @FXML
    private Pane addNewBookWindow;
    private void Clear()
    {
        bookNo.clear();
        bookIndex.clear();
        title.clear();
        author.clear();
        publication.clear();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        // TODO
        itemlist=new ArrayList<BookInfo>();
        cursor=-1;
        back.setDisable(true);
        finish.setDisable(true);
        location.getItems().addAll("主图一楼","主图二楼","主图三楼","主图四楼","主图五楼","东图分馆","医学分馆");
    }    

    @FXML
    private void continueAddItem(ActionEvent event) 
    {
        if(!anyIsEmpty())
        {
            BookInfo o=new BookInfo((Integer.valueOf(bookNo.getText())).longValue(),bookIndex.getText(),title.getText(),location.getSelectionModel().getSelectedItem().toString()
            ,"在架上",author.getText(),publication.getText(),pubdate.getValue().getYear(),pubdate.getValue().getMonthValue());
            itemlist.add(o);
            cursor++;
            back.setDisable(false);
            finish.setDisable(false);
            Clear();
        }
        else
        {
            Alert alert=new Alert(Alert.AlertType.WARNING);
            alert.setTitle("警告");
            alert.setContentText("无法添加空内容");
            alert.showAndWait();
        }
    }

    @FXML
    private void cancleAll(ActionEvent event) 
    {
        itemlist.clear();
        cursor=-1;
        Clear();
        bookborrowsystem.CreateUI.stage.close();
    }

    @FXML
    private void finishAdd(ActionEvent event) throws ClassNotFoundException, SQLException 
    {
        if(itemlist.size()>0)
        {
            finish.setDisable(false);
        }
        else
        {
            finish.setDisable(true);
        }
        BookInfo o;
        Statement stmt = null;
        Connection conn = null;
        Class.forName("oracle.jdbc.OracleDriver");
        conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
        stmt = conn.createStatement();
        int row=0;
        for(int i=0;i<itemlist.size();i++)
        {
            o=itemlist.get(i);
            String sql="insert into BOOK select "+o.getBookNo()+",'"+o.getBookIndex()+"','"+o.getTitle()+"','"
                    +o.getLocation()+"','"+o.getState()+"','"+o.getAuthor()+"','"+o.getPublication()+"',"+o.getYear()+","+o.getMonth()+" from dual where not exists "
                    + "( select * from BOOK t1 where t1.NO="+o.getBookNo()+")";
            System.out.println(sql);
            row=stmt.executeUpdate(sql);
        }
        if(stmt != null) 
        {  
            stmt.close();  
            stmt = null;  
        }  
        if(conn != null) 
        {  
            conn.close();  
            conn = null;  
        }
        if(row==0)
        {
            Alert alert=new Alert(Alert.AlertType.ERROR);
            alert.setTitle("添加出错");
            alert.setContentText("插入出错，可能该图书已经存在!");
            alert.showAndWait();
        }
        System.out.println("have insert "+row+" items");
        Clear();
        itemlist.clear();
        cursor=-1;
        bookborrowsystem.CreateUI.stage.close();
    }

    @FXML
    private void goBack(ActionEvent event) 
    {
        cursor--;
        if(cursor<0)
        {
            back.setDisable(true);
        }
        BookInfo o=itemlist.get(cursor);
        showInfo(o);
    }
    private void showInfo(BookInfo o)
    {
        bookNo.setText(o.getBookNo().toString());
        bookIndex.setText(o.getBookIndex());
        title.setText(o.getTitle());
        location.setValue(o.getLocation());
        author.setText(o.getAuthor());
        publication.setText(o.getPublication());
        pubdate.setValue(LocalDate.MAX);
    }
    private Boolean anyIsEmpty()
    {
        if(bookNo.getText()==null||bookIndex.getText()==null||title.getText()==null||location.getValue()==null
                ||author.getText()==null||publication.getText()==null||pubdate.getValue()==null)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public static class BookInfo
{
    private Long bookNo;
    private String bookIndex;
    private String title;
    private String location;
    private String state;
    private String author;
    private String publication;
    private int year;
    private int month;
    public BookInfo(Long bookNo,String bookIndex,String title,String location,String state,String author,String publication,int year,int month)
    {
        this.bookNo=bookNo;
        this.bookIndex=bookIndex;
        this.author=author;
        this.title=title;
        this.location=location;
        this.publication=publication;
        this.state=state;
        this.year=year;
        this.month=month;
    }
    public Long getBookNo()
    {
        System.out.println("call me");
        return this.bookNo;
    }
    public void setBookNo(Long o)
    {
        this.bookNo=o;
    }
    public String getBookIndex()
    {
        return this.bookIndex;
    }
    public void setBookIndex(String o)
    {
        this.bookIndex=o;
    }
    public String getAuthor()
    {
        return this.author;
    }
    public void setAuthor(String o)
    {
        this.author=o;
    }
    public String getTitle()
    {
        return this.title;
    }
    public void setTitle(String o)
    {
        this.title=o;
    }
    public String getLocation()
    {
        return this.location;
    }
    public void setLocattion(String o)
    {
        this.location=o;
    }
    public String getPublication()
    {
        return this.publication;
    }
    public void setPublication(String o)
    {
        this.publication=o;
    }
    public int getYear()
    {
        return this.year;
    }
    public void setYear(int o)
    {
        this.year=o;
    }
    public int getMonth()
    {
        return this.month;
    }
    public void setMonth(int o)
    {
        this.month=o;
    }
    public String getState()
    {
        return this.state;
    }
    public void setState(String o)
    {
        this.state=o;
    }
}
}
