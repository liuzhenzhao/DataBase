/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookborrowsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.EventHandler;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author liuzhenzhao
 */
public class TableClickEvent implements EventHandler<MouseEvent>
{
    TableView<bookborrowsystem.ReaderSearchBookController.DetailItem> table;
    Boolean selected;
    Long no;
    public TableClickEvent(TableView<ReaderSearchBookController.DetailItem> _table, boolean b) 
    {
        this.table=_table;
        this.selected=b;
    }
    public void handle(MouseEvent event)
    {
        if(selected)
        {
           // System.out.println("hahhahah");
            Alert alert=new Alert(Alert.AlertType.CONFIRMATION,"是否借阅这本书?",new ButtonType("否", ButtonBar.ButtonData.NO),
            new ButtonType("是", ButtonBar.ButtonData.YES));
            alert.setTitle("图书借阅");
            Optional<ButtonType> _buttonType = alert.showAndWait();
            if(_buttonType.get().getButtonData().equals(ButtonBar.ButtonData.YES))
            {
                try {
                    System.out.println("selected no is:"+table.getSelectionModel().getSelectedItem().getBookNo());
                    Long temp1=table.getSelectionModel().getSelectedItem().getBookNo();
                    String temp2=bookborrowsystem.FXMLController._readerAccount;
                    String sql="insert into Borrow(BOOKNO,READERACCOUNT,RETURNDATE,REBORROW) select t1.NO as seqno,t2.ACCOUNT as Account," +
                            "SYSDATE + interval '30' day,0 " +
                            "from BOOK t1,READER t2,dual t3 " +
                            "where t1.NO="+temp1+" and t2.ACCOUNT='"+temp2+
                            "' and t1.STATE='在架上'";
                    String sql1="select count(*) as BN from BORROW t where t.READERACCOUNT='"+temp2+"'";
                    String sql2="select count(*) as TN from TICKET t where t.READERACCOUNT='"+temp2+"'";
                    System.out.println(sql);
                    System.out.println(sql1);
                    System.out.println(sql2);
                    ResultSet rs = null;
                    Statement stmt = null;
                    Connection conn = null;
                    Class.forName("oracle.jdbc.OracleDriver");
                    conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","liuzhao","liuzhao666");
                    stmt = conn.createStatement();
                    rs=stmt.executeQuery(sql1);
                    if(rs.next())
                    {
                        if(rs.getInt("BN")<10)
                        {//借阅数不超过10
                            System.out.println("借阅数量"+rs.getInt("BN"));
                            rs=stmt.executeQuery(sql2);
                            if(rs.next())
                            {
                                if(rs.getInt("TN")==0)
                                {//无罚单
                                    int rows=stmt.executeUpdate(sql);
                                    if(rows<=0)
                                    {
                                        System.out.println("借书失败");
                                        Alert alert1=new Alert(Alert.AlertType.WARNING);
                                        alert1.setTitle("Warning");
                                        alert1.setContentText("借书失败，该书可能不在架上!");
                                        alert1.showAndWait();
                                    }
                                }
                                else
                                {
                                    System.out.println("借书失败");
                                    Alert alert2=new Alert(Alert.AlertType.WARNING);
                                    alert2.setTitle("Warning");
                                    alert2.setContentText("借书失败，请先缴纳罚金!");
                                    alert2.showAndWait();
                                }
                            }
                        }
                    }
                    else
                    {
                        System.out.println("借书失败");
                        Alert alert3=new Alert(Alert.AlertType.WARNING);
                        alert3.setTitle("Warning");
                        alert3.setContentText("借书失败，借阅数不能超过10本!");
                        alert3.showAndWait();
                    }
                    if(stmt != null)
                    {
                        stmt.close();
                        stmt = null;  
                    }
                    if(conn != null)
                    {
                        conn.close();
                        conn = null;
                    }
                    if(rs!=null)
                    {
                        rs.close();
                        rs = null;
                    }
                    } catch (ClassNotFoundException ex) {
                        Logger.getLogger(TableClickEvent.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (SQLException ex) {
                    Logger.getLogger(TableClickEvent.class.getName()).log(Level.SEVERE, null, ex);
                    }
            }
        }
        else
            System.out.println("ooooooooooooooooooo");
    }
}
